--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE lms;
--
-- Name: lms; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE lms WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_IN';


ALTER DATABASE lms OWNER TO postgres;

\connect lms

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    book_id integer NOT NULL,
    title character varying(100) NOT NULL,
    category character varying DEFAULT 'Misc'::character varying NOT NULL,
    print_year character varying(4) NOT NULL,
    author character varying(40) NOT NULL,
    status character varying(1) DEFAULT 'E'::character varying NOT NULL,
    count integer NOT NULL,
    pub_id integer NOT NULL
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: book_book_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.book_book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_book_id_seq OWNER TO postgres;

--
-- Name: book_book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.book_book_id_seq OWNED BY public.book.book_id;


--
-- Name: book_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_request (
    request_id integer NOT NULL,
    member_id integer NOT NULL,
    book_title character varying(100) NOT NULL,
    book_desc character varying(255),
    status character varying(1) DEFAULT 'P'::character varying NOT NULL
);


ALTER TABLE public.book_request OWNER TO postgres;

--
-- Name: book_request_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.book_request_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_request_request_id_seq OWNER TO postgres;

--
-- Name: book_request_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.book_request_request_id_seq OWNED BY public.book_request.request_id;


--
-- Name: issue_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_history (
    issue_id integer NOT NULL,
    member_id integer NOT NULL,
    book_id integer NOT NULL,
    issue_date date DEFAULT CURRENT_DATE NOT NULL,
    return_date date DEFAULT (CURRENT_DATE + make_interval(days => 14)) NOT NULL,
    status character varying(1) DEFAULT 'A'::character varying NOT NULL,
    fine integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.issue_history OWNER TO postgres;

--
-- Name: issue_history_issue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_history_issue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_history_issue_id_seq OWNER TO postgres;

--
-- Name: issue_history_issue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_history_issue_id_seq OWNED BY public.issue_history.issue_id;


--
-- Name: issue_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_request (
    request_id integer NOT NULL,
    member_id integer NOT NULL,
    book_id integer NOT NULL,
    request_date date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.issue_request OWNER TO postgres;

--
-- Name: issue_request_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_request_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_request_request_id_seq OWNER TO postgres;

--
-- Name: issue_request_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_request_request_id_seq OWNED BY public.issue_request.request_id;


--
-- Name: member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.member (
    member_id integer NOT NULL,
    status character varying(1) DEFAULT 'A'::character varying NOT NULL,
    warnings integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.member OWNER TO postgres;

--
-- Name: publisher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.publisher (
    pub_id integer NOT NULL,
    pub_name character varying(30) NOT NULL
);


ALTER TABLE public.publisher OWNER TO postgres;

--
-- Name: publisher_pub_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.publisher_pub_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.publisher_pub_id_seq OWNER TO postgres;

--
-- Name: publisher_pub_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.publisher_pub_id_seq OWNED BY public.publisher.pub_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    first_name character varying(25) NOT NULL,
    last_name character varying(25) NOT NULL,
    phone character varying(10) NOT NULL,
    is_admin character varying(1) DEFAULT 'N'::character varying NOT NULL,
    password character varying(10) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: book book_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book ALTER COLUMN book_id SET DEFAULT nextval('public.book_book_id_seq'::regclass);


--
-- Name: book_request request_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_request ALTER COLUMN request_id SET DEFAULT nextval('public.book_request_request_id_seq'::regclass);


--
-- Name: issue_history issue_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_history ALTER COLUMN issue_id SET DEFAULT nextval('public.issue_history_issue_id_seq'::regclass);


--
-- Name: issue_request request_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_request ALTER COLUMN request_id SET DEFAULT nextval('public.issue_request_request_id_seq'::regclass);


--
-- Name: publisher pub_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publisher ALTER COLUMN pub_id SET DEFAULT nextval('public.publisher_pub_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book (book_id, title, category, print_year, author, status, count, pub_id) FROM stdin;
\.
COPY public.book (book_id, title, category, print_year, author, status, count, pub_id) FROM '$$PATH$$/3069.dat';

--
-- Data for Name: book_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_request (request_id, member_id, book_title, book_desc, status) FROM stdin;
\.
COPY public.book_request (request_id, member_id, book_title, book_desc, status) FROM '$$PATH$$/3075.dat';

--
-- Data for Name: issue_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.issue_history (issue_id, member_id, book_id, issue_date, return_date, status, fine) FROM stdin;
\.
COPY public.issue_history (issue_id, member_id, book_id, issue_date, return_date, status, fine) FROM '$$PATH$$/3071.dat';

--
-- Data for Name: issue_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.issue_request (request_id, member_id, book_id, request_date) FROM stdin;
\.
COPY public.issue_request (request_id, member_id, book_id, request_date) FROM '$$PATH$$/3073.dat';

--
-- Data for Name: member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.member (member_id, status, warnings) FROM stdin;
\.
COPY public.member (member_id, status, warnings) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: publisher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.publisher (pub_id, pub_name) FROM stdin;
\.
COPY public.publisher (pub_id, pub_name) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, first_name, last_name, phone, is_admin, password) FROM stdin;
\.
COPY public.users (user_id, first_name, last_name, phone, is_admin, password) FROM '$$PATH$$/3064.dat';

--
-- Name: book_book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.book_book_id_seq', 1, true);


--
-- Name: book_request_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.book_request_request_id_seq', 1, true);


--
-- Name: issue_history_issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_history_issue_id_seq', 1, true);


--
-- Name: issue_request_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_request_request_id_seq', 1, true);


--
-- Name: publisher_pub_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.publisher_pub_id_seq', 1, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 2, true);


--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (book_id);


--
-- Name: book_request book_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_request
    ADD CONSTRAINT book_request_pkey PRIMARY KEY (request_id);


--
-- Name: issue_history issue_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_history
    ADD CONSTRAINT issue_history_pkey PRIMARY KEY (issue_id);


--
-- Name: issue_request issue_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_request
    ADD CONSTRAINT issue_request_pkey PRIMARY KEY (request_id);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (member_id);


--
-- Name: publisher publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publisher
    ADD CONSTRAINT publisher_pkey PRIMARY KEY (pub_id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: book book_pub_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pub_id_fkey FOREIGN KEY (pub_id) REFERENCES public.publisher(pub_id);


--
-- Name: book_request book_request_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_request
    ADD CONSTRAINT book_request_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(member_id);


--
-- Name: issue_history issue_history_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_history
    ADD CONSTRAINT issue_history_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.book(book_id);


--
-- Name: issue_history issue_history_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_history
    ADD CONSTRAINT issue_history_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(member_id);


--
-- Name: issue_request issue_request_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_request
    ADD CONSTRAINT issue_request_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.book(book_id);


--
-- Name: issue_request issue_request_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_request
    ADD CONSTRAINT issue_request_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.member(member_id);


--
-- Name: member member_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

